let a = 'Hello';
let b = 'Ukraine';
let n = 2020;
let c = a + ' ' + b + ' ' + n;
console.log(c);
console.log(b.length);
console.log(b[2]);
for (let i = 0; i < 5; i++) {
    console.log(i);
}
for (let x = 0; x < b.length; x++) {
    console.log(b[x]);
}
let m = ['qwe', 5, 'asd'];
console.log(m[0]);
let t = [15, 3, 8, 10];
for (let i = 0; i < t.length; i++) {
    if (t[i] > 9) {
        console.log(t[i]);
    }
}
m[0] = 'zxc';
console.log(m);
m[6] = 678;
console.log(m);